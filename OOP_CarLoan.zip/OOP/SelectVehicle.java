import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SelectVehicle extends JFrame {
    
    //Drop Down 
    String[] carBrands = {"Toyota"};
    JComboBox carbrandChoice = new JComboBox(carBrands);
    
    JLabel brand = new JLabel();
    JTextField carSelected = new JTextField();
    JButton select = new JButton();
    
    public SelectVehicle() {
        
        setTitle("Select a Vehicle");
        
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints grid = new GridBagConstraints();
        
        brand.setText("Select a brand   ");
        grid.gridx = 0;
        grid.gridy = 1;
        getContentPane().add(brand, grid);
        
        grid.gridx = 1;
        grid.gridy = 1;
        getContentPane().add(carbrandChoice, grid);
        
        select.setText("Choose");
        grid.gridx = 1;
        grid.gridy = 3; 
        getContentPane().add(select, grid);
        
        select.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                choosecarBrand(e);
            }
        });
        
        pack();
    }
    
    public void choosecarBrand(ActionEvent e) {
        String getcarBrand = (String) carbrandChoice.getSelectedItem();
        
        if (getcarBrand.equals("Toyota")) {
            new Toyota().show();
            this.dispose();
        }
        
        setVisible(false);
    }
    
}