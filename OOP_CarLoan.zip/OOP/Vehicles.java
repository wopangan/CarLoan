public class Vehicles {
    //Instantiation of variables to display the name and the price of vehicles.
    String carName;
    int car1Price, car2Price, car3Price, car4Price, car5Price;
    
    public Vehicles() {
        
    }
    
    //Setter
    public void setCarName(String carName) {
        this.carName = carName;
    }
    
    //Getter
    public String getCarName() {
        return carName;
    }
    
    public int getCar1Price() {
        car1Price = 800000;
        return car1Price;
    }
    
    public int getCar2Price() {
        car2Price = 600000;
        return car2Price;
    }
    
    public int getCar3Price() {
        car3Price = 400000;
        return car3Price;
    }
    
    public int getCar4Price() {
        car4Price = 700000;
        return car4Price;
    }
    
    public int getCar5Price() {
        car5Price = 1500000;
        return car5Price;
    }
    
    
}