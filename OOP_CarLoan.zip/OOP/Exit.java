import javax.swing.*;

public class Exit extends JFrame {
    
    public Exit(){
        //this will exit the whole program.
        JFrame f = new JFrame();
        
        JOptionPane.showMessageDialog(f, "Thank you! Exitting the program...");
        System.exit(0);
    }
}
