import javax.swing.*;
import java.awt.*;

public class Team extends JFrame{
    JLabel team = new JLabel();
    JLabel ong = new JLabel();
    JLabel ongnum = new JLabel();
    JLabel web = new JLabel();
    JLabel webnum = new JLabel();
    JLabel gabe = new JLabel();
    JLabel gabenum = new JLabel();
    JLabel company = new JLabel();
    JLabel companynum = new JLabel();
    
    public Team(){
        //This will only display the labels and their output.
        setTitle("Team");

        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints grid = new GridBagConstraints();

        team.setText("Our Team");
        grid.gridx=1;
        grid.gridy=0;
        getContentPane().add(team,grid);

        ong.setText("Justin Ong - Dealer");
        grid.gridx=1;
        grid.gridy=1;
        getContentPane().add(ong,grid);

        ongnum.setText("123");
        grid.gridx=1;
        grid.gridy=2;
        getContentPane().add(ongnum,grid);

        web.setText("Webster Pangan - General Manager");
        grid.gridx=1;
        grid.gridy=3;
        getContentPane().add(web,grid);

        webnum.setText("456");
        grid.gridx=1;
        grid.gridy=4;
        getContentPane().add(webnum,grid);

        gabe.setText("Gabrielle Dometita - General Sales Manager");
        grid.gridx=1;
        grid.gridy=5;
        getContentPane().add(gabe,grid);

        gabenum.setText("789");
        grid.gridx=1;
        grid.gridy=6;
        getContentPane().add(gabenum,grid);

        company.setText("202 Car Loan");
        grid.gridx=1;
        grid.gridy=7;
        getContentPane().add(company,grid);

        companynum.setText("000");
        grid.gridx=1;
        grid.gridy=8;
        getContentPane().add(companynum,grid);

        pack();
    }
    
    public static void main(String[] args){
        new Team().show();
    }
}