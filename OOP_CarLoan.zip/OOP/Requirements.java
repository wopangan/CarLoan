import javax.swing.*;
import java.awt.*;

public class Requirements extends JFrame
{
    JLabel requirements = new JLabel();
    JLabel requirementsAbroad = new JLabel();
    JLabel applicationform = new JLabel();
    JLabel govID = new JLabel();
    JLabel Lproofobilling = new JLabel();
    JLabel CoE = new JLabel();
    JLabel PaymentSlips = new JLabel();
    JLabel EmployeeContract = new JLabel();
    JLabel CrewContact = new JLabel();
    JLabel ProofofRemittance = new JLabel();
    
    public Requirements(){
        //This will only display the labels and their output.
        setTitle("Car Loan Requirements");

        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints grid = new GridBagConstraints();

        requirements.setText("Car Loan Requirements for Locally Employed");
        grid.gridx=1;
        grid.gridy=0;
        getContentPane().add(requirements,grid);

        applicationform.setText("- Duly accomplished application form.");
        grid.gridx=1;
        grid.gridy=1;
        getContentPane().add(applicationform,grid);

        govID.setText("- Valid government-issued I.D. with signature and photo such as Driver’s License, Passport, etc. of borrower and co-maker (if available).");
        grid.gridx=1;
        grid.gridy=2;
        getContentPane().add(govID,grid);

        Lproofobilling.setText("- The latest proof of billing.");
        grid.gridx=1;
        grid.gridy=3;
        getContentPane().add(Lproofobilling,grid);

        CoE.setText("- Copy of Certificate of Employment (CoE) with compensation and latest income tax return (ITR).");
        grid.gridx=1;
        grid.gridy=4;
        getContentPane().add(CoE,grid);

        PaymentSlips.setText("- Three months’ worth of payslips.");
        grid.gridx=1;
        grid.gridy=5;
        getContentPane().add(PaymentSlips,grid);

        requirementsAbroad.setText("Car Loan Requirements for Employed Abroad");
        grid.gridx=1;
        grid.gridy=6;
        getContentPane().add(requirementsAbroad,grid);

        EmployeeContract.setText("- OFWs must provide the latest employment contract authenticated by the Philippine Consulate.");
        grid.gridx=1;
        grid.gridy=7;
        getContentPane().add(EmployeeContract,grid);

        CrewContact.setText("- Those working as a Seafarer/Seaman must have their latest crew contract.");
        grid.gridx=1;
        grid.gridy=8;
        getContentPane().add(CrewContact,grid);

        ProofofRemittance.setText("- Proof of remittance for the last three months or more.");
        grid.gridx=1;
        grid.gridy=9;
        getContentPane().add(ProofofRemittance,grid);

        pack();
    }
    
    public static void main(String[] args){
        new Requirements().show();
    }
}