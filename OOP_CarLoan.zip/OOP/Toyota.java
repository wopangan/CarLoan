import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Toyota extends JFrame{
    //Methods that can be accessed to another class in order to get the needed values.
    public static String toyotaCarInfo = " ";
    public static int toyotaCarPrice;
    
    //Labels
    JLabel car1 = new JLabel();
    JLabel car2 = new JLabel();
    JLabel car3 = new JLabel();
    JLabel car4 = new JLabel();
    JLabel car5 = new JLabel();
    
    //Buttons
    JButton chooseCar1 = new JButton();
    JButton chooseCar2 = new JButton();
    JButton chooseCar3 = new JButton();
    JButton chooseCar4 = new JButton();
    JButton chooseCar5 = new JButton();
    
    //Class name with object name and constructor. 
    Vehicles vehicles = new Vehicles();
    
    
    public Toyota(){
        setTitle("Toyota");
        
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints grid = new GridBagConstraints();
        
        car1.setText("Innova, Php800,000");
        grid.gridx = 1;
        grid.gridy = 1;
        getContentPane().add(car1, grid);
        
        car2.setText("Corolla, Php600,000");
        grid.gridx = 1;
        grid.gridy = 2;
        getContentPane().add(car2, grid);
        
        car3.setText("Wigo, Php400,000");
        grid.gridx = 1;
        grid.gridy = 3;
        getContentPane().add(car3, grid);
        
        car4.setText("Vios, Php700,000");
        grid.gridx = 1;
        grid.gridy = 4;
        getContentPane().add(car4, grid);
        
        car5.setText("Cruiser, Php1,500,000");
        grid.gridx = 1;
        grid.gridy = 5;
        getContentPane().add(car5, grid);
        
        chooseCar1.setText("Choose");
        grid.gridx = 3; 
        grid.gridy = 1;
        getContentPane().add(chooseCar1, grid);
        
        chooseCar2.setText("Choose");
        grid.gridx = 3;
        grid.gridy = 2;
        getContentPane().add(chooseCar2, grid);
        
        chooseCar3.setText("Choose");
        grid.gridx = 3;
        grid.gridy = 3;
        getContentPane().add(chooseCar3, grid);
        
        chooseCar4.setText("Choose");
        grid.gridx = 3;
        grid.gridy = 4;
        getContentPane().add(chooseCar4, grid);
        
        chooseCar5.setText("Choose");
        grid.gridx = 3;
        grid.gridy = 5;
        getContentPane().add(chooseCar5, grid);
        
    
        pack();
        
        chooseCar1.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               chooseCar1ActionPerformed(e);
           }
        });
        
        chooseCar2.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               chooseCar2ActionPerformed(e);
           }
        });
        
        chooseCar3.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               chooseCar3ActionPerformed(e);
           }
        });
        
        chooseCar4.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               chooseCar4ActionPerformed(e);
           }
        });
        
        chooseCar5.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               chooseCar5ActionPerformed(e);
           }
        });
        
    }
    
    //This button will choose the Innova with the designated price.
    private void chooseCar1ActionPerformed(ActionEvent e) {
        JFrame f = new JFrame();
        this.toyotaCarInfo = "Innova";
        this.toyotaCarPrice = vehicles.getCar1Price();
        
        JOptionPane.showMessageDialog(f, "You selected Innova. Press the finalize button for changes");
        new Account().show();
        this.dispose();
           
    }
    
    //This button will choose the Corolla with the designated price.
    private void chooseCar2ActionPerformed(ActionEvent e) {
        JFrame f = new JFrame();
        this.toyotaCarInfo = "Corolla";
        this.toyotaCarPrice = vehicles.getCar2Price();
        
        JOptionPane.showMessageDialog(f, "You selected Corolla. Press the finalize button for changes");
        new Account().show();
        this.dispose();
           
    }
    
    //This button will choose the Wigo with the designated price.
    private void chooseCar3ActionPerformed(ActionEvent e) {
        JFrame f = new JFrame();
        this.toyotaCarInfo = "Wigo";
        this.toyotaCarPrice = vehicles.getCar3Price();
        
        JOptionPane.showMessageDialog(f, "You selected Wigo. Press the finalize button for changes");
        new Account().show();
        this.dispose();
           
    }
    
    //This button will choose the Vios with the designated price.
    private void chooseCar4ActionPerformed(ActionEvent e) {
        JFrame f = new JFrame();
        this.toyotaCarInfo = "Vios";
        this.toyotaCarPrice = vehicles.getCar4Price();
        
        JOptionPane.showMessageDialog(f, "You selected Vios. Press the finalize button for changes");
        new Account().show();
        this.dispose();
           
    }
    
    //This button will choose the Cruiser with the designated price.
    private void chooseCar5ActionPerformed(ActionEvent e) {
        JFrame f = new JFrame();
        this.toyotaCarInfo = "Cruiser";
        this.toyotaCarPrice = vehicles.getCar5Price();
        
        JOptionPane.showMessageDialog(f, "You selected Cruiser. Press the finalize button for changes");
        new Account().show();
        this.dispose();
           
    }
    
}
    
