import javax.swing.*;
import java.awt.*; 
import java.awt.event.*;

public class Account extends JFrame{
    //Drop Down 
    String[] dealers = {"Gabe", "Ong", "Webster"};
    JComboBox carDealers = new JComboBox(dealers);
    
    //Labels
    JLabel welcome = new JLabel();
    JLabel nameField = new JLabel();
    JLabel contact = new JLabel();
    JLabel address = new JLabel();
    JLabel pack = new JLabel();
    JLabel car = new JLabel();
    JLabel dealer = new JLabel();
    JLabel breakdown = new JLabel();
    JLabel monthly = new JLabel();
    JLabel insurance = new JLabel();
    JLabel service = new JLabel();
    JLabel total = new JLabel();
    
    //Buttons
    JButton finalize = new JButton();
    JButton menu = new JButton();
    JButton packageButton = new JButton();
    JButton vehicleButton = new JButton();
    JButton dealerButton = new JButton();
    JButton okay = new JButton();

    //TextFields
    JTextField contactText= new JTextField();
    JTextField nameText= new JTextField();
    JTextField addressText= new JTextField();
    JTextField packText= new JTextField();
    JTextField carText= new JTextField();
    JTextField dealerText= new JTextField();
    JTextField totalText = new JTextField();
    JTextField monthlyField = new JTextField();
    JTextField insuranceField = new JTextField();
    JTextField serviceField = new JTextField();
    
    //Declaration for car name and package deal for years
    String toyotaCarInfo = Toyota.toyotaCarInfo;
    String packageDeal = Package.packageDeal;
    
    //Instantiation for the car price and package deal
    int carPrice = Toyota.toyotaCarPrice;
    int monthPackage = Package.month;
    int insurancePackage = Package.insurance;
    int servicePackage = Package.service;
    
    //Instantiation for the computation of package deal and car price.
    int totalSubFee = insurancePackage + servicePackage;
    int totalFee = carPrice / monthPackage;
    int totalFinalFee = totalSubFee + totalFee;
        
    Vehicles vehicles = new Vehicles();
    
    public Account(){
        
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Account");
        
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints grid = new GridBagConstraints();
        
        welcome.setText("Fill all information needed:");
        grid.gridx=1;
        grid.gridy=0;
        getContentPane().add(welcome,grid);
        
        nameField.setText("Full Name: ");
        grid.gridx=0;
        grid.gridy=1;
        getContentPane().add(nameField,grid);
        
        nameText.setText("");
        nameText.setColumns(15);
        grid.gridx=1;
        grid.gridy=1;
        getContentPane().add(nameText,grid);
        
        contact.setText("Contact Number: ");
        grid.gridx=0;
        grid.gridy=2;
        getContentPane().add(contact,grid);
        
        contactText.setText("");
        contactText.setColumns(15);
        grid.gridx=1;
        grid.gridy=2;
        getContentPane().add(contactText,grid);
        
        address.setText("Full Address:");
        grid.gridx=0;
        grid.gridy=3;
        getContentPane().add(address,grid);
        
        addressText.setText("");
        addressText.setColumns(15);
        grid.gridx=1;
        grid.gridy=3;
        getContentPane().add(addressText,grid);
        
        pack.setText("Package Deal:");
        grid.gridx=0;
        grid.gridy=4;
        getContentPane().add(pack,grid);
        
        packText.setText(packageDeal);
        packText.setColumns(15);
        packText.setEditable(false);
        grid.gridx=1;
        grid.gridy=4;
        getContentPane().add(packText,grid);
        
        packageButton.setText("See Packages");
        grid.gridx=2;
        grid.gridy=4;
        getContentPane().add(packageButton,grid);
        
        car.setText("Vehicle Type:");
        grid.gridx=0;
        grid.gridy=5;
        getContentPane().add(car,grid);
        
        carText.setText(toyotaCarInfo);
        carText.setColumns(15);
        carText.setEditable(false);
        grid.gridx=1;
        grid.gridy=5;
        getContentPane().add(carText,grid);
        
        vehicleButton.setText("See Vehicles");
        grid.gridx=2;
        grid.gridy=5;
        getContentPane().add(vehicleButton,grid);
        
        dealer.setText("Dealer: ");
        grid.gridx=0;
        grid.gridy=6;
        getContentPane().add(dealer, grid);
        
        grid.gridx = 1;
        grid.gridy = 6;
        getContentPane().add(carDealers, grid);
        
        breakdown.setText("Breakdown of Fees:");
        grid.gridx=1;
        grid.gridy=7;
        getContentPane().add(breakdown,grid);
        
        monthly.setText("Monthly Fees:");
        grid.gridx=0;
        grid.gridy=8;
        getContentPane().add(monthly,grid);
        
        String monthPackage2 = String.valueOf(monthPackage);
        monthlyField.setText("0");
        monthlyField.setColumns(15);
        monthlyField.setEditable(false);
        grid.gridx = 1;
        grid.gridy = 8;
        getContentPane().add(monthlyField,grid);
        
        insurance.setText("Insurance Fee:");
        grid.gridx = 0;
        grid.gridy = 9;
        getContentPane().add(insurance,grid);
        
        String insurancePackage2 = String.valueOf(insurancePackage);
        insuranceField.setText(insurancePackage2);
        insuranceField.setColumns(15);
        insuranceField.setEditable(false);
        grid.gridx= 1;
        grid.gridy= 9;
        getContentPane().add(insuranceField, grid);
        
        service.setText("Service Fees:");
        grid.gridx = 0;
        grid.gridy = 10;
        getContentPane().add(service, grid);
        
        String servicePackage2 = String.valueOf(servicePackage);
        serviceField.setText(servicePackage2);
        serviceField.setColumns(15);
        serviceField.setEditable(false);
        grid.gridx = 1;
        grid.gridy = 10;
        getContentPane().add(serviceField, grid);
        
        total.setText("Total Fees:");
        grid.gridx = 0;
        grid.gridy = 11;
        getContentPane().add(total,grid);
        
        String totalFinalFee = ("");
        totalText.setText(totalFinalFee);
        totalText.setColumns(15);
        totalText.setEditable(false);
        grid.gridx=1;
        grid.gridy=11;
        getContentPane().add(totalText,grid);
        
        finalize.setText("Finalize");
        grid.gridx=1;
        grid.gridy=13;
        getContentPane().add(finalize,grid);
        
        okay.setText("Okay");
        grid.gridx = 2;
        grid.gridy = 13;
        getContentPane().add(okay, grid);
        
        menu.setText("Menu");
        grid.gridx=3;
        grid.gridy=13;
        getContentPane().add(menu,grid);
        
    
        pack();
        
        finalize.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                finalizeActionPerformed(e);
            }    
        });
        
        okay.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                okayActionPerformed(e);
            }
        });
        
        packageButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                packageButtonActionPerformed(e);
            }
        });
        
        vehicleButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                vehicleButtonActionPerformed(e);
            }
        });
        
        menu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                menuActionPerformed(e);
            }
        });
        
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                exitForm(e);
            }
        });
    }
    //This will finalized the breakdown fees, validate input, and show the values.
    private void finalizeActionPerformed(ActionEvent e) {
        JFrame f = new JFrame();
        
        toyotaCarInfo = Toyota.toyotaCarInfo;
        vehicles.setCarName(toyotaCarInfo);
        carText.setText(vehicles.getCarName());
        
        String personName = nameText.getText();
        String contactName = contactText.getText();
        String addressName = addressText.getText();
        
        monthlyField.setText(String.valueOf(totalFee));
        totalText.setText(String.valueOf(totalFinalFee));
        
        if (personName.equals("") && contactName.equals("") && addressName.equals(""))
            JOptionPane.showMessageDialog(f, "Please fill up the missing fields");
        else{
            JOptionPane.showMessageDialog(f, "Finalized!");
        }
                      
        
    }
    
    //This will exit the program after finalizing.
    private void okayActionPerformed(ActionEvent e) {
        JFrame f = new JFrame();
        JOptionPane.showMessageDialog(f, "Thank you for loaning!");
        this.dispose();
    }
    
    private void vehicleButtonActionPerformed(ActionEvent e) {
        new SelectVehicle().show();
        this.dispose();
    }
    
    private void packageButtonActionPerformed(ActionEvent e) {
        new Package().show();
        this.dispose();
    }
    
    private void exitForm(WindowEvent e) {
        JFrame f = new JFrame();
        JOptionPane.showMessageDialog(f, "Thank you!");
    }
    
    private void menuActionPerformed(ActionEvent e) {
        new Menu().show();
        this.dispose();
    }
    
        

    
}