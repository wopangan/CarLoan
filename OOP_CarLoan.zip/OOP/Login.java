import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Login extends JFrame {
    
    //Labels
    JLabel userpassLogin1 = new JLabel();
    JLabel userpassLogin2 = new JLabel();
    JLabel user = new JLabel();
    JLabel pass = new JLabel();
    JLabel success = new JLabel();
    
    //Text Fields
    JTextField userField = new JTextField();
    JPasswordField passField = new JPasswordField();
    
    //Buttons
    JButton login = new JButton();
    
    public Login() {
        setTitle("Login");
        
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints grid = new GridBagConstraints();
        
        user.setText("Username");
        grid.gridx = 0;
        grid.gridy = 0;
        getContentPane().add(user, grid);
        
        pass.setText("Password");
        grid.gridx = 0;
        grid.gridy = 2;
        getContentPane().add(pass, grid);
        
        userpassLogin1.setText("java123");        
        grid.gridx = 0;
        grid.gridy = 4;
        getContentPane().add(userpassLogin1, grid);
        
        userpassLogin2.setText("oop2022");
        grid.gridx = 0;
        grid.gridy = 5;
        getContentPane().add(userpassLogin2, grid);
        
        success.setText("");
        grid.gridx = 0;
        grid.gridy = 3;
        getContentPane().add(success, grid);
        
        userField.setText("");
        userField.setColumns(13);
        grid.gridx = 2;
        grid.gridy = 0;
        getContentPane().add(userField, grid);
        
        passField.setText("");
        passField.setColumns(13);
        grid.gridx = 2; 
        grid.gridy = 2;
        getContentPane().add(passField, grid);
        
        login.setText("Login");
        grid.gridx = 2;
        grid.gridy = 3;
        getContentPane().add(login, grid);
        
        login.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e){
               loginActionPerformed(e);
           }
        });
        
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                exitForm(e);
            }
        });
        
        setSize(300,200);
    }
    
    //This will only accept the strings provided below inside the If statement in order to proceed.
    public void loginActionPerformed(ActionEvent e){
        
        String userLogin = userField.getText();
        String passLogin = passField.getText();
        
        if (userLogin.equals("java123") && passLogin.equals("oop2022")){
            new Menu().show();
            this.dispose();
        } else {
            success.setText(" Invalid! ");
        }
    } 
    
    private void exitForm(WindowEvent e) {
        JFrame f = new JFrame();
        JOptionPane.showMessageDialog(f, "Thank you!");
    }
    
    public static void main(String[] args) {
        new Login().show();
    }
    
}