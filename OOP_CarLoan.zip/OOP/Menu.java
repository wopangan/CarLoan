import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Menu extends JFrame{
    JButton account = new JButton();
    JButton requirements = new JButton();
    JButton vehicle = new JButton();
    JButton team = new JButton();
    JButton exit = new JButton();
    
    public Menu(){
        setTitle("Main Menu");
        
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints grid = new GridBagConstraints();
        
        account.setText("Account");
        grid.gridx=0;
        grid.gridy=0; 
        getContentPane().add(account, grid);
        
        vehicle.setText("Vehicle");
        grid.gridx=0;
        grid.gridy=1; 
        getContentPane().add(vehicle, grid);
        
        requirements.setText("Requirements");
        grid.gridx=0;
        grid.gridy=3; 
        getContentPane().add(requirements, grid);
        
        team.setText("Team");
        grid.gridx=0;
        grid.gridy=5; 
        getContentPane().add(team, grid);
        
        exit.setText("Exit");
        grid.gridx=0;
        grid.gridy=7;
        getContentPane().add(exit, grid);
        
        setSize(200,200);
        
        //Account Button
        account.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               accountActionPerformed(e);
           }
        });
        
        //Vehicle Button
        vehicle.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                vehicleActionPerformed(e);
            }
        });
        
        //Requirements Button
        requirements.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               requirementsActionPerformed(e);
           }
        });
        
        //Team Button
        team.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                teamActionPerformed(e);
            }
        });
        
        //Exit Button
        exit.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               exitActionPerformed(e);
            }
        });
    }
    
    //Shows the "Account" window after pressing the button.
    public void accountActionPerformed(ActionEvent e) {
        new Account().show();
        this.dispose();
    }
    
    //Shows the "Vehicle" window after pressing the button.
    public void vehicleActionPerformed(ActionEvent e) {
        new SelectVehicle().show();
        this.dispose();
    }
    
    //Shows the "Requirements" window after pressing the button.
    public void requirementsActionPerformed(ActionEvent e) {
        new Requirements().show();
    }
    
    //Shows the "Team" window after pressing the button.
    public void teamActionPerformed(ActionEvent e) {
        new Team().show();
    }

    //Exits the program after pressing the "Exit" button.
    public void exitActionPerformed(ActionEvent e) {
        new Exit().show();
        this.dispose();
    }
    
}