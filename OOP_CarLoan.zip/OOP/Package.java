import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Package extends JFrame {
    //Methods that can be accessed to another class with their designated and updated values.
    public static String packageDeal = " ";
    public static int month = 1;
    public static int insurance;
    public static int service;
    
    //Labels
    JLabel year3 = new JLabel();
    JLabel year6 = new JLabel();
    JLabel year9 = new JLabel();
    
    //Buttons
    JButton year3Button = new JButton();
    JButton year6Button = new JButton();
    JButton year9Button = new JButton();
    
    
    
    public Package(){
        setTitle("Package Deal Year");
        
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints grid = new GridBagConstraints();
        
        year3.setText("Package 1");
        grid.gridx = 1;
        grid.gridy = 1;
        getContentPane().add(year3, grid);
        
        year6.setText("Package 2");
        grid.gridx = 1;
        grid.gridy = 2;
        getContentPane().add(year6, grid);
        
        year9.setText("Package 3");
        grid.gridx = 1;
        grid.gridy = 3;
        getContentPane().add(year9, grid);
        
        year3Button.setText("3 Years");
        grid.gridx = 2;
        grid.gridy = 1;
        getContentPane().add(year3Button, grid);
        
        year6Button.setText("6 Years");
        grid.gridx = 2;
        grid.gridy = 2;
        getContentPane().add(year6Button, grid);
        
        year9Button.setText("9 Years");
        grid.gridx = 2;
        grid.gridy = 3;
        getContentPane().add(year9Button, grid);
        
        pack();
        
        year3Button.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               year3ButtonActionPerformed(e);
           }
        });
        
        year6Button.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               year6ButtonActionPerformed(e);
           }
        });
        
        year9Button.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               year9ButtonActionPerformed(e);
           }
        });
        
    }
    
    //This button will display the "Package 1" with the provided values below. 
    private void year3ButtonActionPerformed(ActionEvent e) {
        JFrame f = new JFrame();
        this.packageDeal = "Package 1";
        this.month = 36;
        this.insurance = 350;
        this.service = 150;
        JOptionPane.showMessageDialog(f, "You selected Package 1, Press the finalize button for changes");
        new Account().show();
        this.dispose();    
    }
    
    //This button will display the "Package 2" with the provided values below. 
    private void year6ButtonActionPerformed(ActionEvent e) {
        JFrame f = new JFrame();
        this.packageDeal = "Package 2";
        this.month = 72;
        this.insurance = 350;
        this.service = 150;
        JOptionPane.showMessageDialog(f, "You selected Package 2, Press the finalize button for changes");
        new Account().show();
        this.dispose();    
    }
    
    //This button will display the "Package 3" with the provided values below. 
    private void year9ButtonActionPerformed(ActionEvent e) {
        JFrame f = new JFrame();
        this.packageDeal = "Package 3";
        this.month = 108;
        this.insurance = 350;
        this.service = 150;
        JOptionPane.showMessageDialog(f, "You selected Package 3, Press the finalize button for changes");
        new Account().show();
        this.dispose();    
    }
    
}